import {
  Flame,
  Bell,
  Droplets,
  Droplet,
  CircleDot,
  Shield,
  HardHat,
  Wrench,
  Box,
  Layers,
  Package,
  Waves,
} from 'lucide-react';

export const services = [
  {
    id: 'construction',
    title: 'Civil Works Construction',
    shortTitle: 'Civil Construction',
    description:
      'Construction of residential and commercial buildings, government facilities, and road infrastructure.',
    fullDescription:
      'We undertake civil works projects including residential buildings, commercial structures, government facilities, and road infrastructure. Our team handles supply of materials and complete construction from foundation to finishing.',
    icon: HardHat,
    image: 'https://images.pexels.com/photos/1117210/pexels-photo-1117210.jpeg',
    benefits: [
      'Government-accredited contractor',
      'PCAB licensed for General Building',
      'DPWH registered contractor',
      'Quality materials and workmanship',
      'Road and infrastructure projects',
    ],
  },
  {
    id: 'sprinkler',
    title: 'Automatic Fire Sprinkler System (AFSS)',
    shortTitle: 'Fire Sprinkler Systems',
    description:
      'Design, supply, installation and commissioning of automatic fire sprinkler systems for all building types.',
    fullDescription:
      'Our automatic fire sprinkler systems are designed and installed to comply with NFPA 13 and the Philippine Fire Code. We provide wet pipe, dry pipe, pre-action, and deluge systems custom-designed for your specific building requirements.',
    icon: Flame,
    image: 'https://images.pexels.com/photos/1319460/pexels-photo-1319460.jpeg',
    benefits: [
      '24/7 automatic fire suppression',
      'Reduced property damage',
      'Code compliance guaranteed',
      'All building types served',
      'Minimal maintenance requirements',
    ],
  },
  {
    id: 'fire-suppression',
    title: 'Automatic Fire Suppression System',
    shortTitle: 'Fire Suppression',
    description:
      'Design, supply, installation and commissioning of automatic fire suppression systems for industrial and commercial facilities.',
    fullDescription:
      'We design and install automatic fire suppression systems tailored for industrial and commercial applications. Each system is engineered to the specific hazard class and occupancy requirements of your facility.',
    icon: Shield,
    image: 'https://images.pexels.com/photos/1118417/pexels-photo-1118417.jpeg',
    benefits: [
      'Fast response fire suppression',
      'Engineered for specific hazards',
      'Industrial-grade components',
      'Full commissioning and testing',
      'After-sales maintenance',
    ],
  },
  {
    id: 'alarm',
    title: 'Fire Detection & Alarm System (FDAS)',
    shortTitle: 'Fire Alarm Systems',
    description:
      'Design, supply, installation and commissioning of FDAS — both conventional and addressable types.',
    fullDescription:
      'We provide state-of-the-art fire detection systems including smoke detectors, heat detectors, flame detectors, and manual pull stations. Available in conventional and addressable configurations with centralized monitoring capability.',
    icon: Bell,
    image: 'https://images.pexels.com/photos/1118417/pexels-photo-1118417.jpeg',
    benefits: [
      'Conventional and addressable types',
      'Early fire detection saves lives',
      'Centralized monitoring capability',
      'Smart notification systems',
      'Annual testing and certification',
    ],
  },
  {
    id: 'deluge',
    title: 'Automatic Deluge System',
    shortTitle: 'Deluge System',
    description:
      'Design, supply, installation and commissioning of automatic deluge systems for high-hazard applications.',
    fullDescription:
      'Deluge systems are designed for high-hazard facilities where rapid, total discharge is required. We engineer and install deluge valves, bladder tanks, and associated piping for fuel depots, chemical plants, and aviation facilities.',
    icon: Waves,
    image: 'https://images.pexels.com/photos/1319460/pexels-photo-1319460.jpeg',
    benefits: [
      'Rapid total area discharge',
      'Ideal for high-hazard areas',
      'Fuel depot and aviation ready',
      'Deluge valve and bladder tank supply',
      'Full commissioning',
    ],
  },
  {
    id: 'foam',
    title: 'Foam Suppression System',
    shortTitle: 'Foam Suppression',
    description:
      'Design, supply, installation and commissioning of foam suppression systems — low and high expansion.',
    fullDescription:
      'Our foam suppression systems are designed for high-risk areas handling flammable liquids. We install low and high expansion foam systems for fuel storage, aircraft hangars, and chemical processing facilities. We also supply and install foam bladder tanks with AFFF.',
    icon: CircleDot,
    image: 'https://images.pexels.com/photos/1118417/pexels-photo-1118417.jpeg',
    benefits: [
      'Low and high expansion systems',
      'Effective on flammable liquids',
      'Foam bladder tank with AFFF',
      'Custom design for hazards',
      'Rapid suppression action',
    ],
  },
  {
    id: 'fm200-novec',
    title: 'FM200 / Novec 1230 Suppression System',
    shortTitle: 'FM200 / Novec 1230',
    description:
      'Design, supply, installation and commissioning of FM200 and Novec 1230 clean agent suppression systems.',
    fullDescription:
      'FM200 and Novec 1230 are clean agents that suppress fires without leaving residue or damaging sensitive equipment. Ideal for data centers, server rooms, electrical rooms, and telecommunications facilities.',
    icon: Shield,
    image: 'https://images.pexels.com/photos/1118417/pexels-photo-1118417.jpeg',
    benefits: [
      'No residue after discharge',
      'Safe for sensitive equipment',
      'Electrical room protection',
      'Rapid fire suppression',
      'Environmentally responsible',
    ],
  },
  {
    id: 'co2',
    title: 'CO₂ Suppression System',
    shortTitle: 'CO₂ Systems',
    description:
      'Design, supply, installation and commissioning of CO₂ fire suppression systems for industrial applications.',
    fullDescription:
      'CO₂ suppression systems are highly effective for electrical fires and industrial hazards. We design total flooding and local application systems for power generation facilities and industrial plants.',
    icon: Box,
    image: 'https://images.pexels.com/photos/1118417/pexels-photo-1118417.jpeg',
    benefits: [
      'Effective on electrical fires',
      'No residue after discharge',
      'Total flooding capability',
      'Local application options',
      'Cost-effective solution',
    ],
  },
  {
    id: 'water-tank',
    title: 'Fire Protection Water Storage Tank',
    shortTitle: 'Fire Water Tanks',
    description:
      'Supply, design and build of fire protection water storage tanks for reliable fire water supply.',
    fullDescription:
      'We fabricate and install fire protection water storage tanks from small capacities up to 440,000 liters and beyond. Our tanks are engineered for fire protection service and comply with NFPA requirements.',
    icon: Droplet,
    image: 'https://images.pexels.com/photos/1118417/pexels-photo-1118417.jpeg',
    benefits: [
      'Custom capacity up to 440,000L+',
      'Fire-rated construction',
      'Supply and fabrication service',
      'Corrosion resistant',
      'Level monitoring systems',
    ],
  },
  {
    id: 'equipment-supply',
    title: 'Supply of Fire Protection & FDAS Equipment',
    shortTitle: 'Equipment Supply',
    description:
      'Supply of fire protection and fire detection alarm system equipment for all applications.',
    fullDescription:
      'We supply a comprehensive range of fire protection and FDAS equipment including fire alarm control panels, detectors, sprinkler heads, valves, and all associated components from trusted manufacturers.',
    icon: Package,
    image: 'https://images.pexels.com/photos/1319460/pexels-photo-1319460.jpeg',
    benefits: [
      'Genuine equipment supply',
      'Wide product range',
      'Competitive pricing',
      'Trusted manufacturers',
      'After-sales support',
    ],
  },
  {
    id: 'maintenance',
    title: 'Preventive Maintenance Services',
    shortTitle: 'Preventive Maintenance',
    description:
      'Preventive maintenance services of FDAS and fire suppression systems to ensure operational readiness.',
    fullDescription:
      'Our preventive maintenance programs include regular inspections, testing, and servicing of all fire protection equipment including FDAS and fire suppression systems. We ensure your systems meet code requirements and are always ready.',
    icon: Wrench,
    image: 'https://images.pexels.com/photos/1118417/pexels-photo-1118417.jpeg',
    benefits: [
      'Scheduled inspections',
      'Code compliance guaranteed',
      'Detailed service reporting',
      'Emergency repair services',
      'Parts replacement program',
    ],
  },
  {
    id: 'piping-pump',
    title: 'Piping & Deep Well Pump Installation',
    shortTitle: 'Piping & Deep Well Pump',
    description:
      'Supply and installation of piping systems and deep well pumps for water supply applications.',
    fullDescription:
      'We supply and install industrial piping systems and deep well pumps for fire protection water supply and general water system applications in residential and commercial developments.',
    icon: Droplets,
    image: 'https://images.pexels.com/photos/1117210/pexels-photo-1117210.jpeg',
    benefits: [
      'Industrial-grade piping',
      'Deep well pump installation',
      'Residential and commercial',
      'Full system commissioning',
      'Ongoing maintenance support',
    ],
  },
];

export const distinctiveQualities = [
  { title: 'Affordable Products', description: 'Competitive pricing without compromising quality.' },
  { title: 'Equipment Training', description: 'We train clients on proper usage of all supplied equipment.' },
  { title: 'Unparalleled Customer Service', description: 'Dedicated support before, during, and after every project.' },
  { title: 'On Time Delivery', description: 'We commit to project timelines and deliver on schedule.' },
];

export const serviceCategories = [
  {
    category: 'Suppression Systems',
    services: ['sprinkler', 'fire-suppression', 'deluge', 'foam', 'fm200-novec', 'co2'],
  },
  {
    category: 'Detection & Alarm',
    services: ['alarm'],
  },
  {
    category: 'Water Supply & Infrastructure',
    services: ['water-tank', 'piping-pump'],
  },
  {
    category: 'Equipment & Services',
    services: ['equipment-supply', 'maintenance'],
  },
  {
    category: 'Civil Works',
    services: ['construction'],
  },
];
