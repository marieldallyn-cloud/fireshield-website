export interface BlogPost {
  id: string;
  title: string;
  slug: string;
  excerpt: string;
  content: string;
  image: string;
  author: string;
  category: string;
  publishedAt: string;
  readTime: number;
  featured: boolean;
}

export const blogPosts: BlogPost[] = [
  {
    id: '1',
    title: 'Understanding the Philippine Fire Code: A Comprehensive Guide',
    slug: 'philippine-fire-code-guide',
    excerpt:
      'Learn about the key requirements of the Philippine Fire Code and how they affect your building compliance.',
    content:
      'The Philippine Fire Code (Presidential Decree No. 1185) establishes the minimum requirements for fire protection in buildings...',
    image: 'https://images.pexels.com/photos/1118417/pexels-photo-1118417.jpeg',
    author: 'Engr. Carlos Reyes',
    category: 'Regulations',
    publishedAt: '2024-01-15',
    readTime: 8,
    featured: true,
  },
  {
    id: '2',
    title: 'Fire Sprinkler Systems: Wet vs Dry Pipe Systems Explained',
    slug: 'wet-vs-dry-sprinkler-systems',
    excerpt:
      'Discover the differences between wet and dry pipe sprinkler systems and which one is right for your facility.',
    content:
      'Fire sprinkler systems come in various types, each suited for specific applications...',
    image: 'https://images.pexels.com/photos/1319460/pexels-photo-1319460.jpeg',
    author: 'Engr. Maria Santos',
    category: 'Technical',
    publishedAt: '2024-01-10',
    readTime: 6,
    featured: true,
  },
  {
    id: '3',
    title: 'The Importance of Regular Fire Safety Inspections',
    slug: 'importance-fire-safety-inspections',
    excerpt:
      'Regular fire safety inspections are crucial for maintaining code compliance and ensuring your systems work when needed.',
    content:
      'Fire safety inspections should be conducted regularly to ensure all systems are operational...',
    image: 'https://images.pexels.com/photos/1643343/pexels-photo-1643343.jpeg',
    author: 'Engr. James Cruz',
    category: 'Maintenance',
    publishedAt: '2024-01-05',
    readTime: 5,
    featured: false,
  },
  {
    id: '4',
    title: 'Clean Agent Fire Suppression: FM200 vs Novec 1230',
    slug: 'fm200-vs-novec-1230-comparison',
    excerpt:
      'Compare FM200 and Novec 1230 clean agent systems to make an informed decision for your sensitive equipment.',
    content:
      'Clean agent fire suppression systems are ideal for protecting sensitive electronic equipment...',
    image: 'https://images.pexels.com/photos/1118417/pexels-photo-1118417.jpeg',
    author: 'Engr. Anna Lim',
    category: 'Technical',
    publishedAt: '2023-12-20',
    readTime: 7,
    featured: true,
  },
  {
    id: '5',
    title: 'Fire Pump Maintenance: What You Need to Know',
    slug: 'fire-pump-maintenance-guide',
    excerpt:
      'Proper fire pump maintenance ensures reliable fire protection. Learn the essential maintenance procedures.',
    content:
      'Fire pumps are the heart of your fire protection system. Regular maintenance is essential...',
    image: 'https://images.pexels.com/photos/1118417/pexels-photo-1118417.jpeg',
    author: 'Engr. Carlos Reyes',
    category: 'Maintenance',
    publishedAt: '2023-12-15',
    readTime: 6,
    featured: false,
  },
  {
    id: '6',
    title: 'Fire Safety for High-Rise Buildings: Special Considerations',
    slug: 'high-rise-fire-safety',
    excerpt:
      'High-rise buildings present unique fire safety challenges. Learn about the special requirements and systems involved.',
    content:
      'High-rise buildings require specialized fire protection systems due to their unique challenges...',
    image: 'https://images.pexels.com/photos/1618417/pexels-photo-1618417.jpeg',
    author: 'Engr. Maria Santos',
    category: 'Design',
    publishedAt: '2023-12-10',
    readTime: 9,
    featured: false,
  },
];

export const blogCategories = [
  'All',
  'Technical',
  'Regulations',
  'Maintenance',
  'Design',
  'Industry News',
];
