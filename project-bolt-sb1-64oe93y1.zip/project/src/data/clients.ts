export interface Client {
  id: string;
  name: string;
  location: string;
  industry: string;
  featured: boolean;
}

export const clients: Client[] = [
  { id: 'amspec', name: 'AMSPEC (Amalgamated Specialties Corp.)', location: 'Muntinlupa City', industry: 'Manufacturing', featured: true },
  { id: 'anglo-watsons', name: 'Anglo Watsons Glass Inc.', location: 'Canlubang, Laguna', industry: 'Glass Manufacturing', featured: true },
  { id: 'build-erect', name: 'Build Erect Corporation', location: 'Pasay City', industry: 'Construction', featured: false },
  { id: 'controlgear', name: 'Controlgear Electric Corporation', location: 'Bulacan', industry: 'Electrical', featured: false },
  { id: 'corales-depot', name: 'Corales Depot Corporation', location: 'Surigao del Norte', industry: 'Oil & Gas', featured: false },
  { id: 'em-cuerpo', name: 'E.M. Cuerpo, Inc.', location: 'Bagumbayan, Quezon City', industry: 'Construction', featured: false },
  { id: 'emperador-balayan', name: 'Emperador Distillers, Inc.', location: 'Balayan, Batangas', industry: 'Beverage Manufacturing', featured: true },
  { id: 'emperador-binan', name: 'Emperador Distillers, Inc.', location: 'Biñan City, Laguna', industry: 'Beverage Manufacturing', featured: true },
  { id: 'emperador-tanza', name: 'Emperador Distillers, Inc.', location: 'Ecotown Tanza, Cavite', industry: 'Beverage Manufacturing', featured: true },
  { id: 'emperador-starosa', name: 'Emperador Distillers, Inc.', location: 'Sta. Rosa City, Laguna', industry: 'Beverage Manufacturing', featured: true },
  { id: 'empire-east-mandaluyong', name: 'Empire East Land Holdings, Inc.', location: 'Mandaluyong City', industry: 'Real Estate', featured: true },
  { id: 'empire-east-pasig', name: 'Empire East Land Holdings, Inc.', location: 'Pasig City', industry: 'Real Estate', featured: true },
  { id: 'empire-east-starosa', name: 'Empire East Land Holdings, Inc.', location: 'Sta. Rosa, Laguna', industry: 'Real Estate', featured: true },
  { id: 'flying-v', name: 'Flying V Depot', location: 'Davao City', industry: 'Oil & Gas', featured: true },
  { id: 'insular-oil', name: 'Insular Oil Corporation', location: 'Davao City', industry: 'Oil & Gas', featured: false },
  { id: 'jet-a1', name: 'Jet A1 PAL Oil Depot', location: 'Cebu City', industry: 'Aviation Fuel', featured: true },
  { id: 'johann-construction', name: 'Johann Construction', location: 'Surigao City', industry: 'Construction', featured: false },
  { id: 'mars-philippines', name: 'Mars Philippines, Inc.', location: 'Antipolo City', industry: 'Food Manufacturing', featured: true },
  { id: 'mayapa-cbk', name: 'Mayapa CBK Industry, Inc.', location: 'Calamba, Laguna', industry: 'Manufacturing', featured: false },
  { id: 'meax-trade', name: 'Meax Trade and Services Inc', location: 'San Pascual, Batangas', industry: 'Trading', featured: false },
  { id: 'miescor', name: 'Meralco Industrial Engineering Services Corporation (MIESCOR)', location: 'Zambales', industry: 'Power & Energy', featured: true },
  { id: 'nickel-asia', name: 'Nickel Asia Corporation', location: 'Surigao City', industry: 'Mining', featured: true },
  { id: 'omlf', name: 'OMLF International Trading & Development Corporation (ORIX)', location: 'Calamba, Laguna', industry: 'Trading & Development', featured: false },
  { id: 'omtpi', name: 'OMTPI (Operation & Maintenance Technology Philippines Inc.)', location: 'Sta. Rosa City, Laguna', industry: 'Operations & Maintenance', featured: false },
  { id: 'palilan', name: 'Palilan Oil Depot Corporation', location: 'Misamis Occidental', industry: 'Oil & Gas', featured: false },
  { id: 'parkway-hotel', name: 'Parkway Hotel', location: 'Surigao City', industry: 'Hospitality', featured: false },
  { id: 'petro-de-oro', name: 'Petro De Oro', location: 'Cagayan de Oro', industry: 'Oil & Gas', featured: false },
  { id: 'petrophil', name: 'Petrophil Energy Development Corp', location: 'Negros Occidental', industry: 'Oil & Gas', featured: false },
  { id: 'republic-cement-bulacan', name: 'Republic Cement & Building Materials, Inc.', location: 'Norzagaray, Bulacan', industry: 'Cement Manufacturing', featured: true },
  { id: 'republic-cement-rizal', name: 'Republic Cement & Building Materials, Inc.', location: 'Teresa, Rizal', industry: 'Cement Manufacturing', featured: true },
  { id: 'seashell-petroleum', name: 'Seashell Petroleum Energy Corporation', location: 'Cebu City', industry: 'Oil & Gas', featured: false },
  { id: 'surigao-education', name: 'Surigao Education Center', location: 'Surigao City', industry: 'Education', featured: false },
  { id: 'surigao-state-university', name: 'Surigao State University', location: 'Surigao City', industry: 'Education', featured: false },
  { id: 'universal-leaf-agoo', name: 'Universal Leaf Philippines, Inc.', location: 'Agoo, La Union', industry: 'Agriculture/Tobacco', featured: false },
  { id: 'universal-leaf-candon', name: 'Universal Leaf Philippines, Inc.', location: 'Candon, Ilocos Sur', industry: 'Agriculture/Tobacco', featured: false },
  { id: 'universal-leaf-isabela', name: 'Universal Leaf Philippines, Inc.', location: 'Reina Mercedes, Isabela', industry: 'Agriculture/Tobacco', featured: false },
  { id: 'ushio', name: 'Ushio Philippines, Inc.', location: 'Dasmariñas City, Cavite', industry: 'Manufacturing', featured: false },
];

export const industries = [
  { name: 'Oil & Gas', count: 9, icon: 'Droplets' },
  { name: 'Manufacturing & Industrial', count: 10, icon: 'Factory' },
  { name: 'Real Estate & Construction', count: 8, icon: 'Building2' },
  { name: 'Food & Beverage', count: 5, icon: 'Utensils' },
  { name: 'Mining & Energy', count: 3, icon: 'Zap' },
  { name: 'Education & Government', count: 5, icon: 'Landmark' },
];
