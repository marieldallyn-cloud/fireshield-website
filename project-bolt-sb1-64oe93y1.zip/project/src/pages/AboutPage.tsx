import { motion } from 'framer-motion';
import {
  Target,
  Eye,
  Shield,
  Award,
  Users,
  HardHat,
  CheckCircle,
  Lightbulb,
  Handshake,
  BadgeCheck,
  Leaf,
} from 'lucide-react';
import Section, { SectionHeader, Container } from '../components/ui/Section';
import Button from '../components/ui/Button';

const timeline = [
  {
    year: 'Nov 2016',
    title: 'Company Established',
    description:
      'Fireshield Engineering and Construction Services was founded in November 2016 by Junry Gabradilla Lerio, driven by the need to provide safety and professional guidance for fire and industrial safety equipment.',
  },
  {
    year: 'Feb 2017',
    title: 'Full Operations Commenced',
    description:
      'FECS officially started full operations on February 8, 2017, offering efficient, affordable, and quality services for civil works, industrial, and commercial applications.',
  },
  {
    year: '2018',
    title: 'PhilGEPS Platinum Registration',
    description:
      'Registered in the Philippine Government Electronic Procurement System (PhilGEPS) with Platinum Membership, enabling participation in government procurement projects.',
  },
  {
    year: '2019',
    title: 'Nationwide Expansion',
    description:
      'Expanded operations to serve clients across Luzon, Visayas, and Mindanao, completing major projects for Nickel Asia, Flying V, and Universal Leaf in various regions.',
  },
  {
    year: '2022',
    title: 'PCAB License & DTI Registration',
    description:
      'Obtained PCAB Regular Contractor\'s License (No. 52223) covering General Building, General Engineering, and Specialty-Fire Protection Work. DTI Business Name Registration renewed nationally.',
  },
  {
    year: 'Today',
    title: 'Trusted Industry Partner',
    description:
      'FECS continues to grow as a trusted fire protection and construction company, serving over 37 major clients nationwide with ongoing DPWH and Emperador Distillers projects underway.',
  },
];

const values = [
  {
    icon: <Shield className="w-7 h-7" />,
    title: 'Safety First',
    description:
      'We prioritize safety in everything we do, ensuring our systems protect lives and properties.',
  },
  {
    icon: <BadgeCheck className="w-7 h-7" />,
    title: 'Quality Excellence',
    description:
      'We provide products and services that achieve and sustain the highest possible quality standards.',
  },
  {
    icon: <Lightbulb className="w-7 h-7" />,
    title: 'Latest Technology',
    description:
      'We provide the latest technology and equipment, allowing us to give our customers the best services possible.',
  },
  {
    icon: <Handshake className="w-7 h-7" />,
    title: 'Client Follow-Up',
    description:
      'We follow up on all our clients to ensure that all the supplied equipment is running efficiently and serviced on time.',
  },
  {
    icon: <Users className="w-7 h-7" />,
    title: 'Affordable Service',
    description:
      'We provide efficient, affordable, and quality services that deliver real value for every budget.',
  },
  {
    icon: <Leaf className="w-7 h-7" />,
    title: 'Community Focus',
    description:
      'We are committed to building a safe and secure environment for our community through every project we complete.',
  },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1 },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0 },
};

export default function AboutPage() {
  return (
    <>
      {/* Hero Section */}
      <section className="relative py-24 md:py-32 bg-gradient-to-br from-neutral-900 via-neutral-800 to-neutral-900 overflow-hidden">
        <div className="absolute inset-0 opacity-20">
          <div
            className="absolute inset-0"
            style={{
              backgroundImage: `url('https://images.pexels.com/photos/1117210/pexels-photo-1117210.jpeg')`,
              backgroundSize: 'cover',
              backgroundPosition: 'center',
            }}
          />
        </div>
        <div className="absolute inset-0 bg-gradient-to-r from-neutral-900/90 via-neutral-900/80 to-neutral-900/90" />
        <Container className="relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-3xl"
          >
            <span className="inline-block text-accent-400 font-semibold uppercase tracking-wider text-sm mb-4">
              About FECS
            </span>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-heading font-bold text-white mb-6">
              Protecting Properties.{' '}
              <span className="text-primary-500">Saving Lives.</span>
            </h1>
            <p className="text-lg md:text-xl text-neutral-300">
              Established in 2016, Fireshield Engineering and Construction Services has grown
              into a trusted partner for fire protection and civil works across the Philippines.
            </p>
          </motion.div>
        </Container>
      </section>

      {/* About Us Content */}
      <Section background="white">
        <Container>
          <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <span className="inline-block text-primary-600 font-semibold uppercase tracking-wider text-sm mb-4">
                Who We Are
              </span>
              <h2 className="text-3xl md:text-4xl font-heading font-bold text-neutral-900 mb-6">
                Your Trusted Fire Protection Partner
              </h2>
              <p className="text-neutral-600 mb-4 leading-relaxed">
                Fireshield Engineering and Construction Services was established in November 2016 and
                started its full operations on February 8, 2017. We provide efficient, affordable,
                and quality services for civil works, industrial, and commercial applications.
              </p>
              <p className="text-neutral-600 mb-4 leading-relaxed">
                We also provide the latest technology and equipment, allowing us to give our
                customers the best services possible. We follow up on all of our clients to ensure
                that all the supplied equipment is running efficiently and serviced on time.
              </p>
              <p className="text-neutral-600 leading-relaxed">
                We have grown out of the need of ensuring safety and professional guidance to the
                public for safer and proper usage of all fire and industrial safety equipment.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="relative"
            >
              <div className="rounded-2xl overflow-hidden shadow-2xl">
                <img
                  src="https://images.pexels.com/photos/1117210/pexels-photo-1117210.jpeg"
                  alt="FECS Team at Work"
                  className="w-full h-[400px] object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-neutral-900/40 to-transparent rounded-2xl" />
              </div>
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.3 }}
                className="absolute -bottom-6 -left-6 bg-white rounded-xl p-5 shadow-2xl max-w-xs"
              >
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 bg-primary-100 rounded-full flex items-center justify-center">
                    <Award className="w-5 h-5 text-primary-600" />
                  </div>
                  <div className="font-heading font-bold text-neutral-900">PCAB Licensed</div>
                </div>
                <div className="text-sm text-neutral-600">
                  License No. 52223 — General Building, General Engineering & Fire Protection Work
                </div>
              </motion.div>
            </motion.div>
          </div>

          {/* Mission & Vision */}
          <div className="grid lg:grid-cols-2 gap-8 mb-16">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="bg-primary-600 rounded-2xl p-8 text-white"
            >
              <Target className="w-12 h-12 mb-6" />
              <h3 className="text-2xl font-heading font-bold mb-4">Our Mission</h3>
              <p className="text-primary-100 leading-relaxed">
                It's the policy of the Company to provide customers with products and services that
                achieve and sustain the highest possible quality standards. This statement is the
                basis of our management philosophy, and it reflects the commitment of every
                individual within the organization.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
              className="bg-neutral-900 rounded-2xl p-8 text-white"
            >
              <Eye className="w-12 h-12 mb-6 text-accent-400" />
              <h3 className="text-2xl font-heading font-bold mb-4">Our Vision</h3>
              <p className="text-neutral-300 leading-relaxed">
                Excel in what we do and build a safe and secure environment for our community.
              </p>
            </motion.div>
          </div>

          {/* Core Values */}
          <SectionHeader
            title="Our Core Values"
            highlight="Core "
            subtitle="The principles that guide every project we undertake"
          />

          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            {values.map((value) => (
              <motion.div
                key={value.title}
                variants={itemVariants}
                className="group bg-neutral-50 rounded-xl p-6 hover:bg-white hover:shadow-xl transition-all duration-300"
              >
                <div className="w-14 h-14 bg-primary-100 rounded-xl flex items-center justify-center text-primary-600 mb-4 group-hover:bg-primary-600 group-hover:text-white transition-all duration-300">
                  {value.icon}
                </div>
                <h3 className="text-xl font-heading font-semibold mb-2 text-neutral-900">
                  {value.title}
                </h3>
                <p className="text-neutral-600">{value.description}</p>
              </motion.div>
            ))}
          </motion.div>
        </Container>
      </Section>

      {/* Distinctive Qualities */}
      <Section background="primary">
        <Container>
          <SectionHeader
            title="Our Distinctive Qualities"
            highlight="Distinctive "
            subtitle="What sets FECS apart from the competition"
            light
          />
          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6"
          >
            {[
              { icon: <HardHat className="w-7 h-7" />, title: 'Affordable Products', desc: 'Quality fire protection at competitive prices.' },
              { icon: <Users className="w-7 h-7" />, title: 'Equipment Training', desc: 'We train your team on proper equipment usage.' },
              { icon: <CheckCircle className="w-7 h-7" />, title: 'Unparalleled Customer Service', desc: 'Dedicated support at every step of the project.' },
              { icon: <Award className="w-7 h-7" />, title: 'On Time Delivery', desc: 'We commit to timelines and deliver as promised.' },
            ].map((q) => (
              <motion.div
                key={q.title}
                variants={itemVariants}
                className="bg-white/10 backdrop-blur-sm rounded-xl p-6 text-white text-center"
              >
                <div className="flex justify-center mb-4 text-accent-300">{q.icon}</div>
                <h3 className="font-heading font-bold text-lg mb-2">{q.title}</h3>
                <p className="text-primary-200 text-sm">{q.desc}</p>
              </motion.div>
            ))}
          </motion.div>
        </Container>
      </Section>

      {/* Our Journey Timeline */}
      <Section background="gray">
        <Container>
          <SectionHeader
            title="Our Journey"
            highlight="Our "
            subtitle="From a startup to a trusted industry name in fire protection"
          />

          <div className="relative">
            <div className="absolute left-4 md:left-1/2 top-0 bottom-0 w-0.5 bg-primary-200 -translate-x-1/2" />
            <div className="space-y-12">
              {timeline.map((item, index) => (
                <motion.div
                  key={item.year}
                  initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className={`relative flex items-center ${
                    index % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'
                  }`}
                >
                  <div className="flex-1 hidden md:block" />
                  <div className="absolute left-4 md:left-1/2 w-4 h-4 bg-primary-600 rounded-full -translate-x-1/2 border-4 border-white shadow-lg z-10" />
                  <div className="flex-1 ml-12 md:ml-0 md:px-8">
                    <div className="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-shadow">
                      <span className="text-sm font-bold text-primary-600 mb-2 block">
                        {item.year}
                      </span>
                      <h3 className="text-xl font-heading font-semibold mb-2 text-neutral-900">
                        {item.title}
                      </h3>
                      <p className="text-neutral-600">{item.description}</p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </Container>
      </Section>

      {/* Stats */}
      <Section background="gradient">
        <Container>
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center text-white"
          >
            <div>
              <div className="text-4xl md:text-5xl font-heading font-bold mb-2">9+</div>
              <div className="text-neutral-400">Years of Operations</div>
            </div>
            <div>
              <div className="text-4xl md:text-5xl font-heading font-bold mb-2">100+</div>
              <div className="text-neutral-400">Projects Completed</div>
            </div>
            <div>
              <div className="text-4xl md:text-5xl font-heading font-bold mb-2">37+</div>
              <div className="text-neutral-400">Major Clients</div>
            </div>
            <div>
              <div className="text-4xl md:text-5xl font-heading font-bold mb-2">Nationwide</div>
              <div className="text-neutral-400">Coverage</div>
            </div>
          </motion.div>
        </Container>
      </Section>

      {/* CTA */}
      <Section background="white">
        <Container>
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center max-w-3xl mx-auto"
          >
            <h2 className="text-3xl md:text-4xl font-heading font-bold text-neutral-900 mb-6">
              Ready to Work with Us?
            </h2>
            <p className="text-lg text-neutral-600 mb-8">
              Let us help you protect your property with our expertise in fire protection
              engineering and construction. Contact us today for a free consultation.
            </p>
            <Button to="/contact" variant="primary" size="lg">
              Get Free Consultation
            </Button>
          </motion.div>
        </Container>
      </Section>
    </>
  );
}
