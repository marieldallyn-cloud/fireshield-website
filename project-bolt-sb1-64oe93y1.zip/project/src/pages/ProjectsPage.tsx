import { motion } from 'framer-motion';
import Section, { SectionHeader, Container } from '../components/ui/Section';
import Button from '../components/ui/Button';
import { projectStats } from '../data/projects';
import ProjectGallery from '../components/sections/ProjectGallery';

export default function ProjectsPage() {
  return (
    <>
      {/* Hero Section */}
      <section className="relative py-24 md:py-32 bg-gradient-to-br from-neutral-900 via-neutral-800 to-neutral-900 overflow-hidden">
        <div className="absolute inset-0 opacity-20">
          <div
            className="absolute inset-0"
            style={{
              backgroundImage: `url('https://images.pexels.com/photos/1118417/pexels-photo-1118417.jpeg')`,
              backgroundSize: 'cover',
              backgroundPosition: 'center',
            }}
          />
        </div>
        <div className="absolute inset-0 bg-gradient-to-r from-neutral-900/90 via-neutral-900/80 to-neutral-900/90" />
        <Container className="relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-3xl"
          >
            <span className="inline-block text-accent-400 font-semibold uppercase tracking-wider text-sm mb-4">
              Our Portfolio
            </span>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-heading font-bold text-white mb-6">
              Project{' '}
              <span className="text-primary-500">Showcase</span>
            </h1>
            <p className="text-lg md:text-xl text-neutral-300">
              Explore our portfolio of successful fire protection installations across the Philippines.
            </p>
          </motion.div>
        </Container>
      </section>

      {/* Stats Section */}
      <Section background="white">
        <Container>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {projectStats.map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="text-center p-6 rounded-xl bg-neutral-50"
              >
                <div className="text-3xl md:text-4xl font-heading font-bold text-primary-600 mb-2">
                  {stat.value}
                </div>
                <div className="text-neutral-600 font-medium">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </Container>
      </Section>

      {/* Projects Gallery */}
      <Section background="gray">
        <Container>
          <SectionHeader
            title="Project Gallery"
            highlight="Project "
            subtitle="Click on any project to view details in our interactive gallery"
          />

          <ProjectGallery showAll={true} />
        </Container>
      </Section>

      {/* Featured Clients */}
      <Section background="dark">
        <Container>
          <SectionHeader
            title="Trusted By Industry Leaders"
            highlight="Trusted By "
            subtitle="We've worked with some of the biggest names in Philippine industry"
            light
          />

          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {['Republic Cement', 'Nickel Asia', 'Emperador Distillers', 'Empire East', 'Mars Philippines', 'Flying V', 'Universal Leaf', 'Anglo Watsons'].map(
              (client, index) => (
                <motion.div
                  key={client}
                  initial={{ opacity: 0, scale: 0.9 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.05 }}
                  className="flex items-center justify-center p-6 bg-white/10 backdrop-blur-sm rounded-xl hover:bg-white/20 transition-all duration-300"
                >
                  <span className="text-lg font-semibold text-white text-center">
                    {client}
                  </span>
                </motion.div>
              )
            )}
          </div>
        </Container>
      </Section>

      {/* CTA Section */}
      <Section background="white">
        <Container>
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center max-w-3xl mx-auto"
          >
            <h2 className="text-3xl md:text-4xl font-heading font-bold text-neutral-900 mb-6">
              Start Your Project Today
            </h2>
            <p className="text-lg text-neutral-600 mb-8">
              Join our growing list of satisfied clients. Let us design and implement a fire
              protection system that meets your unique needs.
            </p>
            <Button to="/contact" variant="primary" size="lg">
              Get Free Consultation
            </Button>
          </motion.div>
        </Container>
      </Section>
    </>
  );
}
