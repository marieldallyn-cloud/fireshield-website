import { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Phone,
  Mail,
  MapPin,
  Clock,
  Send,
  Facebook,
  Linkedin,
  Youtube,
  MessageCircle,
  Building,
  User,
  AtSign,
  Briefcase,
} from 'lucide-react';
import Section, { SectionHeader, Container } from '../components/ui/Section';
import Button from '../components/ui/Button';
import { useLocation } from 'react-router-dom';

const contactInfo = [
  {
    icon: MapPin,
    title: 'Office Address',
    details: ['Purok 2, San Jose', 'Lipa City, Batangas', 'Philippines 4217'],
    action: null,
  },
  {
    icon: Phone,
    title: 'Phone Numbers',
    details: ['+63 912 345 6789', '+63 2 8123 4567'],
    action: 'tel:+639123456789',
  },
  {
    icon: Mail,
    title: 'Email Address',
    details: ['info@fireshieldengineering.com'],
    action: 'mailto:info@fireshieldengineering.com',
  },
  {
    icon: Clock,
    title: 'Office Hours',
    details: ['Monday - Friday', '8:00 AM - 5:00 PM', 'Saturday: By Appointment'],
    action: null,
  },
];

const inquiryTypes = [
  'General Inquiry',
  'Fire Sprinkler Systems',
  'Fire Alarm Systems',
  'Fire Pumps',
  'Maintenance Services',
  'Engineering Design',
  'Quotation Request',
  'Partnership Opportunity',
];

export default function ContactPage() {
  const location = useLocation();
  const params = new URLSearchParams(location.search);
  const preselectedService = params.get('service');

  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    company: '',
    inquiryType: preselectedService || '',
    message: '',
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Simulate form submission
    await new Promise((resolve) => setTimeout(resolve, 1500));

    setIsSubmitting(false);
    setSubmitted(true);
  };

  return (
    <>
      {/* Hero Section */}
      <section className="relative py-24 md:py-32 bg-gradient-to-br from-neutral-900 via-neutral-800 to-neutral-900 overflow-hidden">
        <div className="absolute inset-0 opacity-20">
          <div
            className="absolute inset-0"
            style={{
              backgroundImage: `url('https://images.pexels.com/photos/1117210/pexels-photo-1117210.jpeg')`,
              backgroundSize: 'cover',
              backgroundPosition: 'center',
            }}
          />
        </div>
        <div className="absolute inset-0 bg-gradient-to-r from-neutral-900/90 via-neutral-900/80 to-neutral-900/90" />
        <Container className="relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-3xl"
          >
            <span className="inline-block text-accent-400 font-semibold uppercase tracking-wider text-sm mb-4">
              Contact Us
            </span>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-heading font-bold text-white mb-6">
              Get In{' '}
              <span className="text-primary-500">Touch</span>
            </h1>
            <p className="text-lg md:text-xl text-neutral-300">
              Ready to secure your property with reliable fire protection? Contact our team
              today for a free consultation.
            </p>
          </motion.div>
        </Container>
      </section>

      {/* Contact Content */}
      <Section background="gray">
        <Container>
          <div className="grid lg:grid-cols-2 gap-12">
            {/* Contact Information */}
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <span className="text-sm font-semibold text-primary-600 uppercase tracking-wider mb-4 block">
                Contact Information
              </span>
              <h2 className="text-3xl md:text-4xl font-heading font-bold text-neutral-900 mb-6">
                Let's Discuss Your Project
              </h2>
              <p className="text-neutral-600 mb-8">
                Our team is ready to help you with all your fire protection needs. Reach out
                to us through any of the following channels.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-8">
                {contactInfo.map((item) => (
                  <div
                    key={item.title}
                    className="bg-white rounded-xl p-5 shadow-lg hover:shadow-xl transition-shadow"
                  >
                    <div className="w-12 h-12 bg-primary-100 rounded-xl flex items-center justify-center text-primary-600 mb-4">
                      <item.icon className="w-6 h-6" />
                    </div>
                    <h3 className="font-heading font-semibold text-neutral-900 mb-2">
                      {item.title}
                    </h3>
                    <div className="space-y-1">
                      {item.details.map((detail, idx) => (
                        <p key={idx} className="text-neutral-600 text-sm">
                          {detail}
                        </p>
                      ))}
                    </div>
                    {item.action && (
                      <a
                        href={item.action}
                        className="inline-block mt-3 text-primary-600 font-medium text-sm hover:text-primary-700 transition-colors"
                      >
                        Contact Now
                      </a>
                    )}
                  </div>
                ))}
              </div>

              {/* Social Links */}
              <div className="mb-8">
                <h3 className="font-heading font-semibold text-neutral-900 mb-4">Follow Us</h3>
                <div className="flex gap-3">
                  <a
                    href="https://facebook.com/fireshield"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-12 h-12 bg-primary-600 rounded-xl flex items-center justify-center text-white hover:bg-primary-700 transition-colors"
                  >
                    <Facebook className="w-5 h-5" />
                  </a>
                  <a
                    href="https://linkedin.com/company/fireshield"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-12 h-12 bg-primary-600 rounded-xl flex items-center justify-center text-white hover:bg-primary-700 transition-colors"
                  >
                    <Linkedin className="w-5 h-5" />
                  </a>
                  <a
                    href="https://youtube.com/fireshield"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-12 h-12 bg-primary-600 rounded-xl flex items-center justify-center text-white hover:bg-primary-700 transition-colors"
                  >
                    <Youtube className="w-5 h-5" />
                  </a>
                </div>
              </div>

              {/* Map Placeholder */}
              <div className="rounded-2xl overflow-hidden shadow-lg h-64 bg-neutral-200 relative">
                <div className="absolute inset-0 flex items-center justify-center flex-col text-neutral-500">
                  <MapPin className="w-8 h-8 mb-2" />
                  <span className="font-medium">Google Maps</span>
                  <span className="text-sm">Purok 2, San Jose, Lipa City, Batangas</span>
                </div>
              </div>
            </motion.div>

            {/* Contact Form */}
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <div className="bg-white rounded-2xl shadow-xl p-8">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-12 h-12 bg-accent-100 rounded-xl flex items-center justify-center">
                    <MessageCircle className="w-6 h-6 text-accent-600" />
                  </div>
                  <div>
                    <h2 className="text-2xl font-heading font-bold text-neutral-900">
                      Send Us a Message
                    </h2>
                    <p className="text-neutral-500 text-sm">We'll respond within 24 hours</p>
                  </div>
                </div>

                {submitted ? (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="text-center py-12"
                  >
                    <div className="w-20 h-20 bg-accent-100 rounded-full flex items-center justify-center mx-auto mb-6">
                      <Send className="w-10 h-10 text-accent-600" />
                    </div>
                    <h3 className="text-2xl font-heading font-bold text-neutral-900 mb-3">
                      Message Sent!
                    </h3>
                    <p className="text-neutral-600 mb-6">
                      Thank you for contacting us. Our team will review your message and get
                      back to you shortly.
                    </p>
                    <Button onClick={() => setSubmitted(false)} variant="outline">
                      Send Another Message
                    </Button>
                  </motion.div>
                ) : (
                  <form onSubmit={handleSubmit} className="space-y-5">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-neutral-700 mb-1">
                          First Name *
                        </label>
                        <div className="relative">
                          <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-400" />
                          <input
                            type="text"
                            name="firstName"
                            value={formData.firstName}
                            onChange={handleChange}
                            required
                            className="w-full pl-10 pr-4 py-3 rounded-lg border border-neutral-300 focus:border-primary-500 focus:ring-2 focus:ring-primary-200 outline-none transition-all"
                            placeholder="Juan"
                          />
                        </div>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-neutral-700 mb-1">
                          Last Name *
                        </label>
                        <div className="relative">
                          <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-400" />
                          <input
                            type="text"
                            name="lastName"
                            value={formData.lastName}
                            onChange={handleChange}
                            required
                            className="w-full pl-10 pr-4 py-3 rounded-lg border border-neutral-300 focus:border-primary-500 focus:ring-2 focus:ring-primary-200 outline-none transition-all"
                            placeholder="Dela Cruz"
                          />
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-neutral-700 mb-1">
                          Email Address *
                        </label>
                        <div className="relative">
                          <AtSign className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-400" />
                          <input
                            type="email"
                            name="email"
                            value={formData.email}
                            onChange={handleChange}
                            required
                            className="w-full pl-10 pr-4 py-3 rounded-lg border border-neutral-300 focus:border-primary-500 focus:ring-2 focus:ring-primary-200 outline-none transition-all"
                            placeholder="juan@example.com"
                          />
                        </div>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-neutral-700 mb-1">
                          Phone Number
                        </label>
                        <div className="relative">
                          <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-400" />
                          <input
                            type="tel"
                            name="phone"
                            value={formData.phone}
                            onChange={handleChange}
                            className="w-full pl-10 pr-4 py-3 rounded-lg border border-neutral-300 focus:border-primary-500 focus:ring-2 focus:ring-primary-200 outline-none transition-all"
                            placeholder="+63 912 345 6789"
                          />
                        </div>
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-neutral-700 mb-1">
                        Company Name
                      </label>
                      <div className="relative">
                        <Building className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-400" />
                        <input
                          type="text"
                          name="company"
                          value={formData.company}
                          onChange={handleChange}
                          className="w-full pl-10 pr-4 py-3 rounded-lg border border-neutral-300 focus:border-primary-500 focus:ring-2 focus:ring-primary-200 outline-none transition-all"
                          placeholder="Your Company Inc."
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-neutral-700 mb-1">
                        Inquiry Type
                      </label>
                      <div className="relative">
                        <Briefcase className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-400" />
                        <select
                          name="inquiryType"
                          value={formData.inquiryType}
                          onChange={handleChange}
                          className="w-full pl-10 pr-4 py-3 rounded-lg border border-neutral-300 focus:border-primary-500 focus:ring-2 focus:ring-primary-200 outline-none transition-all appearance-none bg-white"
                        >
                          <option value="">Select inquiry type</option>
                          {inquiryTypes.map((type) => (
                            <option key={type} value={type}>{type}</option>
                          ))}
                        </select>
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-neutral-700 mb-1">
                        Message *
                      </label>
                      <textarea
                        name="message"
                        value={formData.message}
                        onChange={handleChange}
                        required
                        rows={5}
                        className="w-full px-4 py-3 rounded-lg border border-neutral-300 focus:border-primary-500 focus:ring-2 focus:ring-primary-200 outline-none transition-all resize-none"
                        placeholder="Tell us about your project or inquiry..."
                      />
                    </div>

                    <Button
                      type="submit"
                      variant="primary"
                      size="lg"
                      className="w-full"
                      loading={isSubmitting}
                    >
                      {isSubmitting ? 'Sending...' : 'Send Message'}
                    </Button>

                    <p className="text-xs text-neutral-500 text-center">
                      By submitting this form, you agree to our privacy policy and terms of
                      service.
                    </p>
                  </form>
                )}
              </div>
            </motion.div>
          </div>
        </Container>
      </Section>

      {/* FAQ Section */}
      <Section background="white">
        <Container>
          <SectionHeader
            title="Frequently Asked Questions"
            highlight="Frequently "
            subtitle="Quick answers to common questions"
          />

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            {[
              {
                q: 'How long does a typical installation take?',
                a: 'Installation time varies based on project scope. A standard sprinkler system may take 2-4 weeks, while complex industrial projects can span several months.',
              },
              {
                q: 'Do you provide maintenance services?',
                a: 'Yes, we offer comprehensive preventive maintenance programs to ensure your fire protection systems remain operational and code-compliant.',
              },
              {
                q: 'What certifications do your engineers hold?',
                a: 'Our engineers are licensed Fire Protection Engineers (FPE) and hold certifications from NFPA, PEO, and other recognized organizations.',
              },
              {
                q: 'Do you work outside Metro Manila?',
                a: 'Yes, we serve clients nationwide across Luzon, Visayas, and Mindanao with full project management and installation capabilities.',
              },
            ].map((faq, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className="bg-neutral-50 rounded-xl p-6"
              >
                <h3 className="font-heading font-semibold text-neutral-900 mb-2">{faq.q}</h3>
                <p className="text-neutral-600 text-sm">{faq.a}</p>
              </motion.div>
            ))}
          </div>
        </Container>
      </Section>
    </>
  );
}
