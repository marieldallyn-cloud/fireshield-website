import { motion } from 'framer-motion';
import { Building2, MapPin } from 'lucide-react';
import Section, { SectionHeader, Container } from '../components/ui/Section';
import Button from '../components/ui/Button';
import { clients, industries } from '../data/clients';

const containerVariants = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { staggerChildren: 0.05 } },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0 },
};

export default function ClientsPage() {
  return (
    <>
      {/* Hero Section */}
      <section className="relative py-24 md:py-32 bg-gradient-to-br from-neutral-900 via-neutral-800 to-neutral-900 overflow-hidden">
        <div className="absolute inset-0 opacity-20">
          <div
            className="absolute inset-0"
            style={{
              backgroundImage: `url('https://images.pexels.com/photos/1117210/pexels-photo-1117210.jpeg')`,
              backgroundSize: 'cover',
              backgroundPosition: 'center',
            }}
          />
        </div>
        <div className="absolute inset-0 bg-gradient-to-r from-neutral-900/90 via-neutral-900/80 to-neutral-900/90" />
        <Container className="relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-3xl"
          >
            <span className="inline-block text-accent-400 font-semibold uppercase tracking-wider text-sm mb-4">
              Our Clients
            </span>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-heading font-bold text-white mb-6">
              Trusted by Industry{' '}
              <span className="text-primary-500">Leaders</span>
            </h1>
            <p className="text-lg md:text-xl text-neutral-300">
              We have partnered with over 37 major companies across the Philippines, delivering
              reliable fire protection and construction solutions.
            </p>
          </motion.div>
        </Container>
      </section>

      {/* Stats */}
      <Section background="white">
        <Container>
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center"
          >
            {[
              { value: '37+', label: 'Major Clients' },
              { value: '100+', label: 'Projects Completed' },
              { value: '40+', label: 'Provinces Covered' },
              { value: '9+', label: 'Years Experience' },
            ].map((stat) => (
              <div key={stat.label} className="p-6 rounded-xl bg-neutral-50">
                <div className="text-3xl md:text-4xl font-heading font-bold text-primary-600 mb-2">
                  {stat.value}
                </div>
                <div className="text-neutral-600 font-medium">{stat.label}</div>
              </div>
            ))}
          </motion.div>
        </Container>
      </Section>

      {/* All Clients List */}
      <Section background="gray">
        <Container>
          <SectionHeader
            title="Our Clients"
            highlight="Our "
            subtitle="Companies that have trusted FECS for their fire protection and construction needs"
          />

          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4"
          >
            {clients.map((client) => (
              <motion.div
                key={client.id}
                variants={itemVariants}
                className="group bg-white rounded-xl p-5 shadow-sm hover:shadow-lg transition-all duration-300 flex items-start gap-4"
              >
                <div className="w-12 h-12 shrink-0 bg-primary-100 rounded-xl flex items-center justify-center text-primary-600 group-hover:bg-primary-600 group-hover:text-white transition-all duration-300">
                  <Building2 className="w-6 h-6" />
                </div>
                <div className="min-w-0">
                  <h3 className="font-heading font-semibold text-neutral-900 text-sm leading-snug mb-1 group-hover:text-primary-600 transition-colors">
                    {client.name}
                  </h3>
                  <div className="flex items-center gap-1 text-xs text-neutral-500">
                    <MapPin className="w-3.5 h-3.5 shrink-0" />
                    <span>{client.location}</span>
                  </div>
                  <span className="inline-block mt-1.5 px-2 py-0.5 bg-neutral-100 text-neutral-600 text-xs rounded-full">
                    {client.industry}
                  </span>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </Container>
      </Section>

      {/* Industries Served */}
      <Section background="white">
        <Container>
          <SectionHeader
            title="Industries We Serve"
            highlight="Industries "
            subtitle="Our expertise spans across multiple sectors of the Philippine economy"
          />

          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid grid-cols-2 md:grid-cols-3 gap-6"
          >
            {industries.map((industry) => (
              <motion.div
                key={industry.name}
                variants={itemVariants}
                className="group bg-neutral-50 rounded-xl p-6 hover:bg-primary-600 transition-all duration-300 cursor-default"
              >
                <Building2 className="w-8 h-8 text-primary-600 mb-3 group-hover:text-white transition-colors" />
                <h3 className="font-heading font-semibold text-neutral-900 group-hover:text-white transition-colors mb-2">
                  {industry.name}
                </h3>
                <p className="text-2xl font-bold text-primary-600 group-hover:text-white transition-colors">
                  {industry.count}+
                </p>
                <p className="text-sm text-neutral-500 group-hover:text-primary-100 transition-colors">
                  Clients Served
                </p>
              </motion.div>
            ))}
          </motion.div>
        </Container>
      </Section>

      {/* Coverage */}
      <Section background="gradient">
        <Container>
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center text-white"
          >
            <MapPin className="w-12 h-12 mx-auto mb-6 text-accent-400" />
            <h2 className="text-3xl md:text-4xl font-heading font-bold mb-4">
              Nationwide Coverage
            </h2>
            <p className="text-lg text-neutral-300 max-w-2xl mx-auto mb-8">
              From Luzon to Mindanao, we have delivered fire protection and construction solutions
              across the Philippine archipelago — Surigao City, Cebu, Davao, Laguna, Bulacan,
              Batangas, Cavite, and beyond.
            </p>
            <div className="grid grid-cols-3 gap-4 max-w-lg mx-auto">
              <div className="bg-white/10 rounded-lg p-4">
                <div className="text-2xl font-bold">Luzon</div>
              </div>
              <div className="bg-white/10 rounded-lg p-4">
                <div className="text-2xl font-bold">Visayas</div>
              </div>
              <div className="bg-white/10 rounded-lg p-4">
                <div className="text-2xl font-bold">Mindanao</div>
              </div>
            </div>
          </motion.div>
        </Container>
      </Section>

      {/* CTA */}
      <Section background="white">
        <Container>
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center max-w-3xl mx-auto"
          >
            <h2 className="text-3xl md:text-4xl font-heading font-bold text-neutral-900 mb-6">
              Join Our Growing Client List
            </h2>
            <p className="text-lg text-neutral-600 mb-8">
              Experience the FECS difference. Let us protect your property with our proven
              fire protection expertise.
            </p>
            <Button to="/contact" variant="primary" size="lg">
              Get Free Consultation
            </Button>
          </motion.div>
        </Container>
      </Section>
    </>
  );
}
