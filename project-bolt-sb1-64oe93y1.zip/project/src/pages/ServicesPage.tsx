import { motion } from 'framer-motion';
import { Link, useLocation } from 'react-router-dom';
import { ArrowRight, CheckCircle, Phone, Mail } from 'lucide-react';
import Section, { SectionHeader, Container } from '../components/ui/Section';
import Button from '../components/ui/Button';
import { services, serviceCategories } from '../data/services';

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1 },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0 },
};

export default function ServicesPage() {
  const location = useLocation();

  return (
    <>
      {/* Hero Section */}
      <section className="relative py-24 md:py-32 bg-gradient-to-br from-neutral-900 via-neutral-800 to-neutral-900 overflow-hidden">
        <div className="absolute inset-0 opacity-20">
          <div
            className="absolute inset-0"
            style={{
              backgroundImage: `url('https://images.pexels.com/photos/1117210/pexels-photo-1117210.jpeg')`,
              backgroundSize: 'cover',
              backgroundPosition: 'center',
            }}
          />
        </div>
        <div className="absolute inset-0 bg-gradient-to-r from-neutral-900/90 via-neutral-900/80 to-neutral-900/90" />
        <Container className="relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-3xl"
          >
            <span className="inline-block text-accent-400 font-semibold uppercase tracking-wider text-sm mb-4">
              Our Services
            </span>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-heading font-bold text-white mb-6">
              Complete Fire Protection{' '}
              <span className="text-primary-500">Solutions</span>
            </h1>
            <p className="text-lg md:text-xl text-neutral-300">
              From design to installation and maintenance, we provide comprehensive fire
              protection services for all building types and industries.
            </p>
          </motion.div>
        </Container>
      </section>

      {/* Services Grid */}
      <Section background="gray">
        <Container>
          <SectionHeader
            title="What We Offer"
            highlight="What We "
            subtitle="Expert fire protection services tailored to your specific needs"
          />

          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8"
          >
            {services.map((service) => (
              <motion.div
                key={service.id}
                id={service.id}
                variants={itemVariants}
                className="group bg-white rounded-xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300"
              >
                {service.image && (
                  <div className="h-48 overflow-hidden">
                    <img
                      src={service.image}
                      alt={service.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  </div>
                )}
                <div className="p-6">
                  <div className="w-14 h-14 bg-primary-50 rounded-xl flex items-center justify-center text-primary-600 mb-4 group-hover:bg-primary-600 group-hover:text-white transition-all duration-300">
                    <service.icon className="w-7 h-7" />
                  </div>
                  <h3 className="text-xl font-heading font-semibold mb-3 text-neutral-900 group-hover:text-primary-600 transition-colors">
                    {service.title}
                  </h3>
                  <p className="text-neutral-600 mb-4">{service.description}</p>

                  {service.benefits && (
                    <div className="space-y-2 mb-4">
                      {service.benefits.slice(0, 3).map((benefit) => (
                        <div
                          key={benefit}
                          className="flex items-center gap-2 text-sm text-neutral-600"
                        >
                          <CheckCircle className="w-4 h-4 text-accent-500 shrink-0" />
                          <span>{benefit}</span>
                        </div>
                      ))}
                    </div>
                  )}

                  <Link
                    to={`/contact?service=${service.id}`}
                    className="inline-flex items-center text-primary-600 font-medium gap-2 hover:gap-3 transition-all duration-300"
                  >
                    Request Quote
                    <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </Link>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </Container>
      </Section>

      {/* Process Section */}
      <Section background="white">
        <Container>
          <SectionHeader
            title="Our Process"
            highlight="Our "
            subtitle="A systematic approach to delivering fire protection excellence"
          />

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {[
              {
                step: '01',
                title: 'Consultation',
                description: 'We assess your fire protection needs and building requirements.',
              },
              {
                step: '02',
                title: 'Design',
                description: 'Our engineers create custom designs that meet all codes.',
              },
              {
                step: '03',
                title: 'Installation',
                description: 'Certified technicians execute the installation with precision.',
              },
              {
                step: '04',
                title: 'Maintenance',
                description: 'Ongoing support to ensure your systems remain operational.',
              },
            ].map((phase, index) => (
              <motion.div
                key={phase.step}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="text-center p-6 rounded-xl bg-neutral-50 hover:bg-white hover:shadow-lg transition-all duration-300"
              >
                <div className="text-4xl font-heading font-bold text-primary-600 mb-4">
                  {phase.step}
                </div>
                <h3 className="text-xl font-heading font-semibold mb-2 text-neutral-900">
                  {phase.title}
                </h3>
                <p className="text-neutral-600">{phase.description}</p>
              </motion.div>
            ))}
          </div>
        </Container>
      </Section>

      {/* CTA Section */}
      <Section background="primary">
        <Container>
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center text-white"
          >
            <h2 className="text-3xl md:text-4xl font-heading font-bold mb-6">
              Need a Custom Solution?
            </h2>
            <p className="text-lg text-neutral-200 max-w-2xl mx-auto mb-8">
              Our engineers are ready to design a fire protection system tailored to your
              specific requirements. Get a free consultation today.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button to="/contact" variant="secondary" size="lg">
                Get Free Consultation
              </Button>
              <a
                href="tel:+639123456789"
                className="inline-flex items-center justify-center gap-2 text-white font-semibold hover:text-accent-300 transition-colors"
              >
                <Phone className="w-5 h-5" />
                +63 912 345 6789
              </a>
            </div>
          </motion.div>
        </Container>
      </Section>
    </>
  );
}
