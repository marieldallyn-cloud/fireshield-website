import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import {
  Shield,
  Award,
  Users,
  MapPin,
  Flame,
  Bell,
  Droplets,
  Droplet,
  CircleDot,
  HardHat,
  Wrench,
  CheckCircle,
  ArrowRight,
} from 'lucide-react';
import Section, { SectionHeader, Container } from '../components/ui/Section';
import Button from '../components/ui/Button';
import ProjectGallery from '../components/sections/ProjectGallery';

const stats = [
  { value: '9+', label: 'Years Experience', icon: <Award className="w-6 h-6" /> },
  { value: '100+', label: 'Completed Projects', icon: <HardHat className="w-6 h-6" /> },
  { value: '30+', label: 'Major Clients', icon: <Users className="w-6 h-6" /> },
  { value: 'Nationwide', label: 'Coverage', icon: <MapPin className="w-6 h-6" /> },
];

const servicesData = [
  {
    icon: <Flame className="w-7 h-7" />,
    title: 'Automatic Fire Sprinkler Systems',
    description:
      'Complete design, installation, and maintenance of automatic fire sprinkler systems for all building types.',
  },
  {
    icon: <Bell className="w-7 h-7" />,
    title: 'Fire Detection & Alarm Systems',
    description:
      'Advanced fire detection with early warning capabilities, integrated monitoring, and smart building connectivity.',
  },
  {
    icon: <Droplets className="w-7 h-7" />,
    title: 'Fire Pumps',
    description:
      'High-performance fire pump systems including electric, diesel, and jockey pumps for reliable water supply.',
  },
  {
    icon: <Droplet className="w-7 h-7" />,
    title: 'Fire Hydrant Systems',
    description:
      'Complete fire hydrant installations including underground piping, hydrant boxes, and hose connections.',
  },
  {
    icon: <CircleDot className="w-7 h-7" />,
    title: 'Foam Suppression Systems',
    description:
      'Foam-based fire suppression ideal for flammable liquid storage and industrial applications.',
  },
  {
    icon: <Shield className="w-7 h-7" />,
    title: 'Clean Agent Systems',
    description:
      'FM200 and Novec 1230 clean agent suppression for data centers and sensitive equipment rooms.',
  },
];

const features = [
  {
    icon: <Users className="w-7 h-7" />,
    title: 'Experienced Engineers',
    description: 'Our licensed engineers bring decades of fire protection experience to every project.',
  },
  {
    icon: <Award className="w-7 h-7" />,
    title: 'Certified Professionals',
    description: 'All our technicians are certified and undergo continuous training on latest codes.',
  },
  {
    icon: <Shield className="w-7 h-7" />,
    title: 'Premium Materials',
    description: 'We use only UL-listed and FM-approved materials from trusted manufacturers.',
  },
  {
    icon: <HardHat className="w-7 h-7" />,
    title: 'Customized Solutions',
    description: 'Every system is custom-designed for your building\'s specific requirements.',
  },
  {
    icon: <CheckCircle className="w-7 h-7" />,
    title: 'Industry Compliance',
    description: 'All installations comply with NFPA, Philippine Fire Code, and local regulations.',
  },
  {
    icon: <Wrench className="w-7 h-7" />,
    title: 'Reliable After-sales Support',
    description: '24/7 support and comprehensive maintenance programs to keep systems running.',
  },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0 },
};

export default function HomePage() {
  return (
    <>
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        {/* Background */}
        <div className="absolute inset-0 z-0">
          <div
            className="absolute inset-0 bg-cover bg-center"
            style={{
              backgroundImage: `linear-gradient(to bottom, rgba(0,0,0,0.6) 0%, rgba(0,0,0,0.4) 50%, rgba(0,0,0,0.7) 100%), url('https://images.pexels.com/photos/1117210/pexels-photo-1117210.jpeg')`,
            }}
          />
          <div className="absolute inset-0 bg-gradient-to-r from-neutral-900/80 via-transparent to-neutral-900/80" />
        </div>

        {/* Animated Background Elements */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-20 left-10 w-64 h-64 bg-primary-600/10 rounded-full blur-3xl animate-pulse" />
          <div className="absolute bottom-20 right-10 w-96 h-96 bg-accent-500/10 rounded-full blur-3xl animate-pulse delay-1000" />
        </div>

        {/* Content */}
        <div className="relative z-10 container-custom text-center text-white px-4">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="max-w-4xl mx-auto"
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.2 }}
              className="inline-flex items-center gap-2 bg-accent-500/20 backdrop-blur-sm border border-accent-500/30 rounded-full px-4 py-2 mb-8"
            >
              <Shield className="w-4 h-4 text-accent-400" />
              <span className="text-sm font-medium text-accent-300">
                Philippines' Premier Fire Protection Company
              </span>
            </motion.div>

            <h1 className="text-4xl md:text-6xl lg:text-7xl font-heading font-bold leading-tight mb-6">
              Protecting Properties.
              <br />
              <span className="text-primary-500">Saving Lives.</span>
            </h1>

            <p className="text-lg md:text-xl text-neutral-300 max-w-3xl mx-auto mb-10">
              Reliable, code-compliant fire protection engineering solutions for commercial,
              industrial, residential, and government projects across the Philippines.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button to="/contact" variant="primary" size="lg">
                Get Free Consultation
              </Button>
              <Button to="/projects" variant="outline" size="lg" className="!border-white !text-white hover:!bg-white/10">
                View Projects
              </Button>
            </div>
          </motion.div>

          {/* Stats */}
          <motion.div
            initial={{ opacity: 0, y: 100 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5, duration: 0.8 }}
            className="mt-16 md:mt-24 grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6"
          >
            {stats.map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.7 + index * 0.1 }}
                className="p-4 md:p-6 rounded-2xl bg-white/5 backdrop-blur-sm border border-white/10 hover:bg-white/10 transition-all duration-300"
              >
                <div className="text-accent-400 mb-2 flex justify-center">{stat.icon}</div>
                <div className="text-2xl md:text-4xl font-heading font-bold text-white mb-1">
                  {stat.value}
                </div>
                <div className="text-sm md:text-base text-neutral-400 font-medium">
                  {stat.label}
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>

        {/* Scroll Indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.5 }}
          className="absolute bottom-8 left-1/2 -translate-x-1/2"
        >
          <div className="w-6 h-10 rounded-full border-2 border-white/30 flex justify-center pt-2">
            <motion.div
              animate={{ y: [0, 12, 0] }}
              transition={{ duration: 1.5, repeat: Infinity }}
              className="w-1.5 h-3 bg-white/50 rounded-full"
            />
          </div>
        </motion.div>
      </section>

      {/* Services Section */}
      <Section background="gray" id="services">
        <Container>
          <SectionHeader
            title="Our Services"
            highlight="Our "
            subtitle="Comprehensive fire protection solutions from design to installation and maintenance"
          />

          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8"
          >
            {servicesData.map((service, index) => (
              <motion.div key={service.title} variants={itemVariants}>
                <div className="group h-full bg-white rounded-xl p-6 shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-2">
                  <div className="w-14 h-14 bg-primary-50 rounded-xl flex items-center justify-center text-primary-600 mb-5 group-hover:bg-primary-600 group-hover:text-white transition-all duration-300">
                    {service.icon}
                  </div>
                  <h3 className="text-xl font-heading font-semibold mb-3 text-neutral-900 group-hover:text-primary-600 transition-colors">
                    {service.title}
                  </h3>
                  <p className="text-neutral-600 mb-4">{service.description}</p>
                  <Link
                    to="/services"
                    className="inline-flex items-center text-primary-600 font-medium group-hover:gap-3 gap-2 transition-all duration-300"
                  >
                    Learn More
                    <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </Link>
                </div>
              </motion.div>
            ))}
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="text-center mt-12"
          >
            <Button to="/services" variant="primary">
              View All Services
            </Button>
          </motion.div>
        </Container>
      </Section>

      {/* Projects Section */}
      <Section background="white" id="projects">
        <Container>
          <SectionHeader
            title="Featured Projects"
            highlight="Featured "
            subtitle="Click on any project to explore our interactive gallery"
          />

          <ProjectGallery showAll={false} />

          <div className="text-center mt-12">
            <Button to="/projects" variant="outline">
              View All Projects
            </Button>
          </div>
        </Container>
      </Section>

      {/* About Section */}
      <Section background="gradient">
        <Container>
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="text-white"
            >
              <span className="inline-block text-accent-400 font-semibold uppercase tracking-wider text-sm mb-4">
                About FECS
              </span>
              <h2 className="text-3xl md:text-4xl lg:text-5xl font-heading font-bold mb-6">
                Your Trusted Partner in Fire Protection
              </h2>
              <p className="text-neutral-300 mb-6 text-lg leading-relaxed">
                Fireshield Engineering and Construction Services (FECS) has been at the
                forefront of fire protection engineering in the Philippines for over 9 years.
                We deliver reliable, code-compliant solutions that protect properties and save
                lives.
              </p>
              <p className="text-neutral-400 mb-8">
                From automatic sprinkler systems to advanced fire detection, our team of
                licensed engineers and certified technicians ensures every installation meets
                the highest standards of quality and safety.
              </p>

              <div className="grid grid-cols-2 gap-6 mb-8">
                <div>
                  <div className="text-3xl font-heading font-bold text-white mb-1">100+</div>
                  <div className="text-neutral-400">Projects Completed</div>
                </div>
                <div>
                  <div className="text-3xl font-heading font-bold text-white mb-1">30+</div>
                  <div className="text-neutral-400">Major Clients</div>
                </div>
              </div>

              <Button to="/about" variant="accent">
                Learn More About Us
              </Button>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="relative"
            >
              <div className="relative rounded-2xl overflow-hidden shadow-2xl">
                <img
                  src="https://images.pexels.com/photos/1117210/pexels-photo-1117210.jpeg"
                  alt="Fire Protection Engineering"
                  className="w-full h-[400px] object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-neutral-900/50 to-transparent" />
              </div>

              {/* Floating Card */}
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.3 }}
                className="absolute -bottom-6 -left-6 bg-white rounded-xl p-5 shadow-2xl max-w-xs"
              >
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-10 h-10 bg-accent-100 rounded-full flex items-center justify-center">
                    <Shield className="w-5 h-5 text-accent-600" />
                  </div>
                  <div className="font-heading font-bold text-neutral-900">NFPA Certified</div>
                </div>
                <div className="text-sm text-neutral-600">
                  Compliant with international fire protection standards
                </div>
              </motion.div>
            </motion.div>
          </div>
        </Container>
      </Section>

      {/* Why Choose Us Section */}
      <Section background="gray">
        <Container>
          <SectionHeader
            title="Why Choose FECS?"
            highlight="Why Choose "
            subtitle="We deliver excellence in fire protection through expertise, quality, and commitment"
          />

          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8"
          >
            {features.map((feature) => (
              <motion.div
                key={feature.title}
                variants={itemVariants}
                className="group bg-white rounded-xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 text-center hover:-translate-y-2"
              >
                <div className="w-16 h-16 mx-auto bg-gradient-to-br from-primary-500 to-primary-600 rounded-2xl flex items-center justify-center text-white mb-5 shadow-lg group-hover:scale-110 transition-transform duration-300">
                  {feature.icon}
                </div>
                <h3 className="text-xl font-heading font-semibold mb-3 text-neutral-900">
                  {feature.title}
                </h3>
                <p className="text-neutral-600">{feature.description}</p>
              </motion.div>
            ))}
          </motion.div>
        </Container>
      </Section>

      {/* CTA Section */}
      <Section background="primary">
        <Container>
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="text-center text-white py-8"
          >
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-heading font-bold mb-6">
              Ready to Protect Your Property?
            </h2>
            <p className="text-lg md:text-xl text-neutral-200 max-w-2xl mx-auto mb-10">
              Get a free consultation from our fire protection experts. Let us design a solution
              that fits your needs.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button to="/contact" variant="secondary" size="lg">
                Get Free Consultation
              </Button>
              <Button to="/services" variant="outline" size="lg" className="!border-white !text-white hover:!bg-white/10">
                Explore Our Services
              </Button>
            </div>
          </motion.div>
        </Container>
      </Section>
    </>
  );
}
