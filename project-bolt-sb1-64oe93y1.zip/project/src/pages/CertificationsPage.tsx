import { motion } from 'framer-motion';
import { Award, BadgeCheck, FileCheck, Building, Shield, CheckCircle, Landmark, Receipt } from 'lucide-react';
import Section, { SectionHeader, Container } from '../components/ui/Section';
import Button from '../components/ui/Button';

const certifications = [
  {
    name: 'PCAB License',
    description: 'Regular Contractor\'s License No. 52223',
    details: 'General Building (D), General Engineering, Specialty-Fire Protection Work. Valid March 14, 2026 – March 14, 2027. Region 4A (CALABARZON).',
    issuer: 'Philippine Contractors Accreditation Board – DTI',
    icon: Building,
    highlight: true,
  },
  {
    name: 'PhilGEPS Platinum',
    description: 'Certificate of PhilGEPS Registration (Platinum Membership)',
    details: 'Cert. Ref. No. 201807-92238-1859219259. Registered 02-Jul-2018. Valid until 09-Mar-2027.',
    issuer: 'Department of Budget and Management – Procurement Service',
    icon: Award,
    highlight: true,
  },
  {
    name: 'DPWH-CRC',
    description: 'Contractor Registration Certificate',
    details: 'Contractor ID No. 52223. Authorized for Fire Protection Work – Small B. Issued March 22, 2023.',
    issuer: 'Department of Public Works and Highways – Central Office',
    icon: Landmark,
    highlight: true,
  },
  {
    name: 'DTI Registration',
    description: 'Certificate of Business Name Registration (National)',
    details: 'Business Name No. 3589899. Registered to Junry Gabradilla Lerio. Valid Feb 9, 2022 – Feb 9, 2027.',
    issuer: 'Department of Trade and Industry',
    icon: BadgeCheck,
    highlight: true,
  },
  {
    name: 'BIR Certificate',
    description: 'Certificate of Registration (COR)',
    details: 'TIN 908-272-604-000. Registered business name: Fireshield Engineering and Construction Services. Covers fire safety products and construction of buildings.',
    issuer: 'Bureau of Internal Revenue – Revenue Region 09A',
    icon: Receipt,
    highlight: false,
  },
  {
    name: 'Mayor\'s Permit 2026',
    description: 'Business License & Mayor\'s Permit',
    details: 'Permit No. 2026-08437. Issued Feb 9, 2026. Valid until Dec 31, 2026. Nature of business: Rendering Construction Services / Retailing of Fire Safety Products.',
    issuer: 'City of Lipa – Office of the Mayor',
    icon: FileCheck,
    highlight: false,
  },
];

const compliance = [
  {
    code: 'NFPA 13',
    title: 'Standard for Installation of Sprinkler Systems',
    description: 'All sprinkler system installations designed and installed in compliance with NFPA 13.',
  },
  {
    code: 'NFPA 20',
    title: 'Standard for Installation of Stationary Fire Pumps',
    description: 'Fire pump installations meeting NFPA 20 requirements for electric and diesel-driven pumps.',
  },
  {
    code: 'NFPA 14',
    title: 'Standard for Installation of Standpipe Systems',
    description: 'Standpipe and wet standpipe systems designed per NFPA 14 specifications.',
  },
  {
    code: 'NFPA 72',
    title: 'National Fire Alarm and Signaling Code',
    description: 'Fire detection and alarm systems conforming to NFPA 72 — both conventional and addressable.',
  },
  {
    code: 'Philippine Fire Code',
    title: 'PD 1185 – Fire Code of the Philippines',
    description: 'Full compliance with the Philippine Fire Code requirements for all installations.',
  },
  {
    code: 'RA 4566',
    title: 'Contractors\' License Law',
    description: 'Licensed pursuant to Republic Act No. 4566 and its implementing rules and regulations.',
  },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { staggerChildren: 0.1 } },
};

const itemVariants = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0 },
};

export default function CertificationsPage() {
  return (
    <>
      {/* Hero Section */}
      <section className="relative py-24 md:py-32 bg-gradient-to-br from-neutral-900 via-neutral-800 to-neutral-900 overflow-hidden">
        <div className="absolute inset-0 opacity-20">
          <div
            className="absolute inset-0"
            style={{
              backgroundImage: `url('https://images.pexels.com/photos/1117210/pexels-photo-1117210.jpeg')`,
              backgroundSize: 'cover',
              backgroundPosition: 'center',
            }}
          />
        </div>
        <div className="absolute inset-0 bg-gradient-to-r from-neutral-900/90 via-neutral-900/80 to-neutral-900/90" />
        <Container className="relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-3xl"
          >
            <span className="inline-block text-accent-400 font-semibold uppercase tracking-wider text-sm mb-4">
              Certifications & Licenses
            </span>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-heading font-bold text-white mb-6">
              Certified{' '}
              <span className="text-primary-500">Excellence</span>
            </h1>
            <p className="text-lg md:text-xl text-neutral-300">
              Our government-issued certifications and licenses demonstrate our compliance,
              credibility, and commitment to quality in every project we undertake.
            </p>
          </motion.div>
        </Container>
      </section>

      {/* Certifications Grid */}
      <Section background="white">
        <Container>
          <SectionHeader
            title="Our Licenses & Certifications"
            highlight="Our "
            subtitle="Government-recognized credentials that validate our expertise and legal authority to operate"
          />

          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            {certifications.map((cert) => (
              <motion.div
                key={cert.name}
                variants={itemVariants}
                className={`group rounded-2xl p-7 transition-all duration-300 hover:shadow-xl ${
                  cert.highlight
                    ? 'bg-primary-600 text-white'
                    : 'bg-neutral-100 text-neutral-900 hover:bg-white'
                }`}
              >
                <cert.icon
                  className={`w-10 h-10 mb-4 ${cert.highlight ? 'text-accent-300' : 'text-primary-600'}`}
                />
                <h3 className="text-xl font-heading font-bold mb-1">{cert.name}</h3>
                <p className={`font-medium text-sm mb-3 ${cert.highlight ? 'text-primary-100' : 'text-primary-600'}`}>
                  {cert.description}
                </p>
                <p className={`text-sm mb-4 leading-relaxed ${cert.highlight ? 'text-primary-200' : 'text-neutral-600'}`}>
                  {cert.details}
                </p>
                <div className={`text-xs font-semibold uppercase tracking-wide ${cert.highlight ? 'text-primary-300' : 'text-neutral-400'}`}>
                  {cert.issuer}
                </div>
              </motion.div>
            ))}
          </motion.div>
        </Container>
      </Section>

      {/* Compliance Standards */}
      <Section background="gray">
        <Container>
          <SectionHeader
            title="Standards Compliance"
            highlight="Standards "
            subtitle="We adhere to the highest international and local fire protection standards"
          />

          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            {compliance.map((item) => (
              <motion.div
                key={item.code}
                variants={itemVariants}
                className="group bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-all duration-300"
              >
                <div className="flex items-start gap-4">
                  <div className="w-14 h-14 bg-accent-100 rounded-xl flex items-center justify-center shrink-0">
                    <FileCheck className="w-7 h-7 text-accent-600" />
                  </div>
                  <div>
                    <div className="text-sm font-bold text-accent-600 mb-1">{item.code}</div>
                    <h3 className="font-heading font-semibold text-neutral-900 mb-2">
                      {item.title}
                    </h3>
                    <p className="text-sm text-neutral-600">{item.description}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </Container>
      </Section>

      {/* Quality Promise */}
      <Section background="gradient">
        <Container>
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center text-white"
          >
            <Shield className="w-16 h-16 mx-auto mb-6 text-accent-400" />
            <h2 className="text-3xl md:text-4xl font-heading font-bold mb-6">
              Our Quality Promise
            </h2>
            <p className="text-lg text-neutral-300 max-w-3xl mx-auto mb-8">
              Every project we undertake is backed by our government-issued licenses and our
              commitment to quality. We don't just meet standards — we exceed them to ensure
              your property is properly protected.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6">
                <div className="text-2xl font-bold mb-2">PCAB #52223</div>
                <div className="text-neutral-400 text-sm">Licensed Contractor</div>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6">
                <div className="text-2xl font-bold mb-2">PhilGEPS Platinum</div>
                <div className="text-neutral-400 text-sm">Government Registered</div>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6">
                <div className="text-2xl font-bold mb-2">DPWH-CRC</div>
                <div className="text-neutral-400 text-sm">Fire Protection Work</div>
              </div>
            </div>
          </motion.div>
        </Container>
      </Section>

      {/* CTA */}
      <Section background="white">
        <Container>
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center max-w-3xl mx-auto"
          >
            <h2 className="text-3xl md:text-4xl font-heading font-bold text-neutral-900 mb-6">
              Partner with a Licensed Expert
            </h2>
            <p className="text-lg text-neutral-600 mb-8">
              Work with confidence knowing FECS holds all required government licenses and
              certifications. Contact us for your next project.
            </p>
            <Button to="/contact" variant="primary" size="lg">
              Get Free Consultation
            </Button>
          </motion.div>
        </Container>
      </Section>
    </>
  );
}
