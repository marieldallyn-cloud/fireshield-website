import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, ArrowLeft, ArrowRight, MapPin, Building2, CheckCircle, Clock, ZoomIn } from 'lucide-react';
import { projects } from '../../data/projects';

interface ProjectGalleryProps {
  showAll?: boolean;
}

export default function ProjectGallery({ showAll = false }: ProjectGalleryProps) {
  const [selectedProject, setSelectedProject] = useState<typeof projects[0] | null>(null);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [hoveredId, setHoveredId] = useState<string | null>(null);

  const displayProjects = showAll ? projects : projects.filter((p) => p.highlight);

  const openLightbox = (project: typeof projects[0], index: number) => {
    setSelectedProject(project);
    setCurrentIndex(index);
  };

  const closeLightbox = () => {
    setSelectedProject(null);
  };

  const navigatePrev = () => {
    const newIndex = currentIndex === 0 ? displayProjects.length - 1 : currentIndex - 1;
    setCurrentIndex(newIndex);
    setSelectedProject(displayProjects[newIndex]);
  };

  const navigateNext = () => {
    const newIndex = currentIndex === displayProjects.length - 1 ? 0 : currentIndex + 1;
    setCurrentIndex(newIndex);
    setSelectedProject(displayProjects[newIndex]);
  };

  return (
    <>
      {/* Gallery Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {displayProjects.map((project, index) => (
          <motion.div
            key={project.id}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            onMouseEnter={() => setHoveredId(project.id)}
            onMouseLeave={() => setHoveredId(null)}
            className="group relative cursor-pointer"
            onClick={() => openLightbox(project, index)}
          >
            <div className="relative overflow-hidden rounded-2xl aspect-[4/3]">
              {/* Image */}
              <img
                src={project.image}
                alt={project.title}
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-125"
              />

              {/* Overlay Gradient */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent opacity-80 group-hover:opacity-100 transition-opacity duration-300" />

              {/* Hover Effect - Diagonal Reveal */}
              <div className="absolute inset-0 bg-primary-600 transform -translate-x-full group-hover:translate-x-0 transition-transform duration-500 ease-out"
                style={{
                  clipPath: 'polygon(0 0, 100% 0, 100% 100%, 0 100%)',
                  WebkitClipPath: 'polygon(0 0, 85% 0, 100% 100%, 0 100%)',
                }}
              >
                <div className="absolute inset-0 opacity-20">
                  <div className="absolute inset-0 bg-gradient-to-br from-primary-500 to-primary-700" />
                </div>
              </div>

              {/* Zoom Icon */}
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-all duration-300 z-10">
                <motion.div
                  initial={{ scale: 0 }}
                  whileHover={{ scale: 1 }}
                  className="w-16 h-16 bg-white/90 rounded-full flex items-center justify-center shadow-2xl"
                >
                  <ZoomIn className="w-8 h-8 text-primary-600" />
                </motion.div>
              </div>

              {/* Content */}
              <div className="absolute bottom-0 left-0 right-0 p-6 z-10">
                {/* Service Badge */}
                <motion.div
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: hoveredId === project.id ? 0 : 20, opacity: hoveredId === project.id ? 1 : 0 }}
                  transition={{ duration: 0.3 }}
                  className="mb-2"
                >
                  <span className="inline-block px-3 py-1 bg-accent-500 text-white text-xs font-semibold rounded-full uppercase tracking-wider">
                    {project.service}
                  </span>
                </motion.div>

                {/* Title */}
                <h3 className="text-xl md:text-2xl font-heading font-bold text-white mb-3 group-hover:text-accent-300 transition-colors duration-300">
                  {project.title}
                </h3>

                {/* Meta Info */}
                <div className="flex flex-wrap items-center gap-4 text-sm text-neutral-300">
                  <div className="flex items-center gap-1">
                    <Building2 className="w-4 h-4 text-accent-400" />
                    <span>{project.client}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <MapPin className="w-4 h-4 text-accent-400" />
                    <span>{project.location}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    {project.status === 'completed' ? (
                      <CheckCircle className="w-4 h-4 text-accent-400" />
                    ) : (
                      <Clock className="w-4 h-4 text-yellow-400" />
                    )}
                    <span className={project.status === 'ongoing' ? 'text-yellow-300' : ''}>
                      {project.status === 'completed' ? 'Completed' : 'Ongoing'}
                    </span>
                  </div>
                </div>

                {/* Description - Reveals on Hover */}
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{
                    height: hoveredId === project.id ? 'auto' : 0,
                    opacity: hoveredId === project.id ? 1 : 0,
                  }}
                  transition={{ duration: 0.4 }}
                  className="overflow-hidden"
                >
                  <p className="mt-4 text-neutral-300 text-sm line-clamp-2">
                    {project.description}
                  </p>
                </motion.div>
              </div>

              {/* Corner Decoration */}
              <div className="absolute top-4 right-4 w-8 h-8 border-t-2 border-r-2 border-white/30 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              <div className="absolute bottom-4 left-4 w-8 h-8 border-b-2 border-l-2 border-white/30 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
            </div>
          </motion.div>
        ))}
      </div>

      {/* Lightbox Modal */}
      <AnimatePresence>
        {selectedProject && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/95 backdrop-blur-lg"
            onClick={closeLightbox}
          >
            {/* Close Button */}
            <button
              onClick={closeLightbox}
              className="absolute top-6 right-6 z-50 p-3 bg-white/10 hover:bg-white/20 rounded-full transition-colors duration-300"
            >
              <X className="w-6 h-6 text-white" />
            </button>

            {/* Navigation Buttons */}
            <button
              onClick={(e) => {
                e.stopPropagation();
                navigatePrev();
              }}
              className="absolute left-6 top-1/2 -translate-y-1/2 z-50 p-4 bg-white/10 hover:bg-white/20 rounded-full transition-colors duration-300 group"
            >
              <ArrowLeft className="w-8 h-8 text-white group-hover:-translate-x-1 transition-transform duration-300" />
            </button>

            <button
              onClick={(e) => {
                e.stopPropagation();
                navigateNext();
              }}
              className="absolute right-6 top-1/2 -translate-y-1/2 z-50 p-4 bg-white/10 hover:bg-white/20 rounded-full transition-colors duration-300 group"
            >
              <ArrowRight className="w-8 h-8 text-white group-hover:translate-x-1 transition-transform duration-300" />
            </button>

            {/* Modal Content */}
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              transition={{ type: 'spring', damping: 25, stiffness: 300 }}
              className="max-w-5xl w-full mx-4 bg-neutral-900 rounded-2xl overflow-hidden shadow-2xl"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="grid md:grid-cols-2">
                {/* Image Side */}
                <div className="relative aspect-square md:aspect-auto md:h-[500px]">
                  <img
                    src={selectedProject.image}
                    alt={selectedProject.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent to-neutral-900 hidden md:block" />
                </div>

                {/* Content Side */}
                <div className="p-8 flex flex-col justify-center">
                  <span className="inline-block px-4 py-1.5 bg-accent-500/20 text-accent-400 text-sm font-semibold rounded-full mb-4 w-fit">
                    {selectedProject.service}
                  </span>

                  <h2 className="text-2xl md:text-3xl font-heading font-bold text-white mb-4">
                    {selectedProject.title}
                  </h2>

                  <p className="text-neutral-400 mb-6 leading-relaxed">
                    {selectedProject.description}
                  </p>

                  {/* Meta Grid */}
                  <div className="grid grid-cols-2 gap-4 mb-6">
                    <div className="bg-neutral-800 rounded-xl p-4">
                      <div className="text-neutral-500 text-sm mb-1">Client</div>
                      <div className="text-white font-semibold">{selectedProject.client}</div>
                    </div>
                    <div className="bg-neutral-800 rounded-xl p-4">
                      <div className="text-neutral-500 text-sm mb-1">Location</div>
                      <div className="text-white font-semibold">{selectedProject.location}</div>
                    </div>
                    <div className="bg-neutral-800 rounded-xl p-4">
                      <div className="text-neutral-500 text-sm mb-1">Status</div>
                      <div className={`font-semibold capitalize ${selectedProject.status === 'ongoing' ? 'text-yellow-400' : 'text-accent-400'}`}>
                        {selectedProject.status}
                      </div>
                    </div>
                    <div className="bg-neutral-800 rounded-xl p-4">
                      <div className="text-neutral-500 text-sm mb-1">Service Type</div>
                      <div className="text-white font-semibold">{selectedProject.service}</div>
                    </div>
                  </div>

                  {/* Scope of Work */}
                  {selectedProject.scopeOfWork && (
                    <div>
                      <h4 className="text-white font-semibold mb-2">Scope of Work</h4>
                      <div className="flex flex-wrap gap-2">
                        {selectedProject.scopeOfWork.map((item) => (
                          <span
                            key={item}
                            className="px-3 py-1 bg-neutral-800 text-neutral-300 text-sm rounded-lg"
                          >
                            {item}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Gallery Navigation Dots */}
              <div className="flex justify-center gap-2 p-4 bg-neutral-800/50">
                {displayProjects.map((_, idx) => (
                  <button
                    key={idx}
                    onClick={(e) => {
                      e.stopPropagation();
                      setCurrentIndex(idx);
                      setSelectedProject(displayProjects[idx]);
                    }}
                    className={`w-2 h-2 rounded-full transition-all duration-300 ${
                      idx === currentIndex
                        ? 'bg-primary-500 w-6'
                        : 'bg-neutral-600 hover:bg-neutral-500'
                    }`}
                  />
                ))}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
