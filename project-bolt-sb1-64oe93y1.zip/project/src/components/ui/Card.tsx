import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

interface CardProps {
  children: React.ReactNode;
  className?: string;
  hover?: boolean;
  padding?: 'none' | 'sm' | 'md' | 'lg';
}

export function Card({ children, className = '', hover = true, padding = 'md' }: CardProps) {
  const paddings = {
    none: '',
    sm: 'p-4',
    md: 'p-6',
    lg: 'p-8',
  };

  return (
    <motion.div
      whileHover={hover ? { y: -8, scale: 1.02 } : {}}
      transition={{ duration: 0.3 }}
      className={`bg-white rounded-xl shadow-lg hover:shadow-2xl transition-all duration-300 overflow-hidden ${paddings[padding]} ${className}`}
    >
      {children}
    </motion.div>
  );
}

interface ServiceCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  href?: string;
  image?: string;
}

export function ServiceCard({ icon, title, description, href, image }: ServiceCardProps) {
  const content = (
    <div className="group h-full flex flex-col">
      {image && (
        <div className="h-48 overflow-hidden">
          <img
            src={image}
            alt={title}
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
          />
        </div>
      )}
      <div className="p-6 flex-grow flex flex-col">
        <div className="w-14 h-14 bg-primary-50 rounded-xl flex items-center justify-center text-primary-600 mb-4 group-hover:bg-primary-600 group-hover:text-white transition-all duration-300">
          {icon}
        </div>
        <h3 className="text-xl font-heading font-semibold mb-3 text-neutral-900 group-hover:text-primary-600 transition-colors">
          {title}
        </h3>
        <p className="text-neutral-600 flex-grow">{description}</p>
        <div className="mt-4 flex items-center text-primary-600 font-medium group-hover:gap-3 gap-2 transition-all duration-300">
          <span>Learn More</span>
          <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
        </div>
      </div>
    </div>
  );

  if (href) {
    return (
      <Link to={href}>
        <Card>{content}</Card>
      </Link>
    );
  }

  return <Card>{content}</Card>;
}

interface ProjectCardProps {
  title: string;
  client: string;
  location: string;
  image: string;
  service: string;
}

export function ProjectCard({ title, client, location, image, service }: ProjectCardProps) {
  return (
    <Card padding="none" className="group cursor-pointer">
      <div className="relative h-64 overflow-hidden">
        <img
          src={image}
          alt={title}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
        <div className="absolute bottom-4 left-4 right-4">
          <span className="text-xs font-semibold text-accent-400 uppercase tracking-wider">
            {service}
          </span>
          <h3 className="text-xl font-heading font-bold text-white mt-1">{title}</h3>
        </div>
      </div>
      <div className="p-5">
        <div className="flex justify-between items-center text-sm text-neutral-500">
          <span className="font-medium text-neutral-700">{client}</span>
          <span>{location}</span>
        </div>
      </div>
    </Card>
  );
}

interface StatCardProps {
  value: string;
  label: string;
  icon?: React.ReactNode;
}

export function StatCard({ value, label, icon }: StatCardProps) {
  return (
    <div className="text-center p-6 rounded-2xl bg-white/10 backdrop-blur-sm border border-white/20">
      {icon && <div className="text-accent-400 mb-3">{icon}</div>}
      <div className="text-4xl md:text-5xl font-heading font-bold text-white mb-2">{value}</div>
      <div className="text-neutral-300 font-medium">{label}</div>
    </div>
  );
}

interface FeatureCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
}

export function FeatureCard({ icon, title, description }: FeatureCardProps) {
  return (
    <Card className="text-center p-8">
      <div className="w-16 h-16 mx-auto bg-gradient-to-br from-primary-500 to-primary-600 rounded-2xl flex items-center justify-center text-white mb-5 shadow-lg">
        {icon}
      </div>
      <h3 className="text-xl font-heading font-semibold mb-3 text-neutral-900">{title}</h3>
      <p className="text-neutral-600">{description}</p>
    </Card>
  );
}
