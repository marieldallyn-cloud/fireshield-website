import { motion } from 'framer-motion';

interface SectionProps {
  children: React.ReactNode;
  className?: string;
  id?: string;
  background?: 'white' | 'gray' | 'dark' | 'gradient' | 'primary';
}

export default function Section({
  children,
  className = '',
  id,
  background = 'white',
}: SectionProps) {
  const backgrounds = {
    white: 'bg-white',
    gray: 'bg-neutral-50',
    dark: 'bg-neutral-900 text-white',
    gradient: 'bg-gradient-to-br from-neutral-900 via-neutral-800 to-neutral-900 text-white',
    primary: 'bg-primary-700 text-white',
  };

  return (
    <section id={id} className={`py-16 md:py-24 ${backgrounds[background]} ${className}`}>
      {children}
    </section>
  );
}

interface SectionHeaderProps {
  title: string;
  subtitle?: string;
  centered?: boolean;
  light?: boolean;
  highlight?: string;
}

export function SectionHeader({
  title,
  subtitle,
  centered = true,
  light = false,
  highlight,
}: SectionHeaderProps) {
  const titlePart = title.split(highlight || '')[0];
  const highlightPart = highlight;
  const restPart = highlight ? title.split(highlight)[1] : '';

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6 }}
      className={`${centered ? 'text-center' : ''} mb-12 md:mb-16`}
    >
      <h2
        className={`text-3xl md:text-4xl lg:text-5xl font-heading font-bold ${
          light ? 'text-white' : 'text-neutral-900'
        }`}
      >
        {titlePart}
        {highlightPart && (
          <span className="text-primary-500">{highlightPart}</span>
        )}
        {restPart}
      </h2>
      {subtitle && (
        <p
          className={`mt-4 text-lg md:text-xl ${
            light ? 'text-neutral-300' : 'text-neutral-600'
          } max-w-3xl ${centered ? 'mx-auto' : ''}`}
        >
          {subtitle}
        </p>
      )}
    </motion.div>
  );
}

interface ContainerProps {
  children: React.ReactNode;
  className?: string;
}

export function Container({ children, className = '' }: ContainerProps) {
  return <div className={`max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 ${className}`}>{children}</div>;
}
