import { Fire, Shield } from 'lucide-react';
import { Link } from 'react-router-dom';

interface LogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
  showText?: boolean;
}

export default function Logo({ className = '', size = 'md', showText = true }: LogoProps) {
  const sizes = {
    sm: { icon: 'w-6 h-6', text: 'text-lg' },
    md: { icon: 'w-8 h-8', text: 'text-xl' },
    lg: { icon: 'w-12 h-12', text: 'text-3xl' },
  };

  return (
    <Link to="/" className={`flex items-center gap-2 group ${className}`}>
      <div className="relative">
        <Shield className={`${sizes[size].icon} text-primary-600 transform group-hover:scale-110 transition-transform duration-300`} />
        <Flame className={`${sizes[size].icon} text-accent-500 absolute top-0 left-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300`} />
      </div>
      {showText && (
        <div className="flex flex-col">
          <span className={`${sizes[size].text} font-heading font-bold text-neutral-900 tracking-tight`}>
            <span className="text-primary-600">Fire</span>shield
          </span>
          <span className={`text-[10px] md:text-xs text-neutral-500 tracking-widest uppercase font-medium -mt-1`}>
            Engineering & Construction
          </span>
        </div>
      )}
    </Link>
  );
}
