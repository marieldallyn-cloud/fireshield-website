import { Link } from 'react-router-dom';
import {
  Phone,
  Mail,
  MapPin,
  Facebook,
  Linkedin,
  Youtube,
  Clock,
  ArrowRight,
} from 'lucide-react';
import Logo from './Logo';

const quickLinks = [
  { name: 'Home', href: '/' },
  { name: 'About Us', href: '/about' },
  { name: 'Services', href: '/services' },
  { name: 'Projects', href: '/projects' },
  { name: 'Contact', href: '/contact' },
];

const services = [
  { name: 'Fire Sprinkler Systems', href: '/services#sprinkler' },
  { name: 'Fire Detection & Alarm', href: '/services#alarm' },
  { name: 'Foam Suppression System', href: '/services#foam' },
  { name: 'FM200 / Novec 1230', href: '/services#fm200-novec' },
  { name: 'Preventive Maintenance', href: '/services#maintenance' },
  { name: 'Civil Works Construction', href: '/services#construction' },
];

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-neutral-900 text-white">
      {/* Main Footer */}
      <div className="container-custom py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Company Info */}
          <div className="space-y-6">
            <div className="text-white">
              <Logo showText={true} />
            </div>
            <p className="text-neutral-400 leading-relaxed">
              Protecting Properties. Saving Lives. Philippines' premier fire protection
              engineering company delivering code-compliant solutions nationwide.
            </p>
            <div className="flex gap-4">
              <a
                href="https://facebook.com/fireshield"
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 bg-neutral-800 rounded-lg hover:bg-primary-600 transition-colors duration-300"
              >
                <Facebook className="w-5 h-5" />
              </a>
              <a
                href="https://linkedin.com/company/fireshield"
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 bg-neutral-800 rounded-lg hover:bg-primary-600 transition-colors duration-300"
              >
                <Linkedin className="w-5 h-5" />
              </a>
              <a
                href="https://youtube.com/fireshield"
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 bg-neutral-800 rounded-lg hover:bg-primary-600 transition-colors duration-300"
              >
                <Youtube className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-heading font-semibold mb-6">Quick Links</h3>
            <ul className="space-y-3">
              {quickLinks.map((link) => (
                <li key={link.name}>
                  <Link
                    to={link.href}
                    className="text-neutral-400 hover:text-white transition-colors duration-300 flex items-center gap-2 group"
                  >
                    <ArrowRight className="w-4 h-4 opacity-0 -ml-6 group-hover:opacity-100 group-hover:ml-0 transition-all duration-300" />
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h3 className="text-lg font-heading font-semibold mb-6">Our Services</h3>
            <ul className="space-y-3">
              {services.map((service) => (
                <li key={service.name}>
                  <Link
                    to={service.href}
                    className="text-neutral-400 hover:text-white transition-colors duration-300 flex items-center gap-2 group"
                  >
                    <ArrowRight className="w-4 h-4 opacity-0 -ml-6 group-hover:opacity-100 group-hover:ml-0 transition-all duration-300" />
                    {service.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-lg font-heading font-semibold mb-6">Contact Us</h3>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-primary-500 mt-1 shrink-0" />
                <span className="text-neutral-400">
                  Purok 2, San Jose, Lipa City,
                  Batangas, Philippines 4217
                </span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="w-5 h-5 text-primary-500 shrink-0" />
                <a href="tel:+639123456789" className="text-neutral-400 hover:text-white transition-colors">
                  +63 912 345 6789
                </a>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-primary-500 shrink-0" />
                <a href="mailto:info@fireshieldengineering.com" className="text-neutral-400 hover:text-white transition-colors">
                  info@fireshieldengineering.com
                </a>
              </li>
              <li className="flex items-center gap-3">
                <Clock className="w-5 h-5 text-primary-500 shrink-0" />
                <span className="text-neutral-400">Mon - Fri: 8:00 AM - 5:00 PM</span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-neutral-800">
        <div className="container-custom py-6 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-neutral-500 text-sm">
            &copy; {currentYear} Fireshield Engineering and Construction Services. All rights
            reserved.
          </p>
          <div className="flex gap-6 text-sm">
            <Link to="/privacy" className="text-neutral-500 hover:text-white transition-colors">
              Privacy Policy
            </Link>
            <Link to="/terms" className="text-neutral-500 hover:text-white transition-colors">
              Terms of Service
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
